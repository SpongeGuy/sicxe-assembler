# SIC/XE two-pass assembler
written in python
use `python main.py` to run the program
inside the program is a `sample` variable. change this variable to the path of different assembly files to generate code for them.